fx_version 'adamant'
game 'gta5'

ui_page 'html/ui.html'

files {
	'html/*',
}

client_scripts {
	"client/client.lua"
}